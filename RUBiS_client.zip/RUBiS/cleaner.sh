sudo mv bench/2017*/* /var/www/html/stats;
sudo rm -R bench/2017*;
